The archive contains the following:

    A file containing the data uploaded to the dashboard (trending_by_time.csv)
    A link to the dashboard on Tableau Public's server in the text file
    A presentation file in PDF
    Instructions on how to start all the files (readme.txt)
	
	